'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const FILEBEAT_CLOUD_INSTRUCTIONS = exports.FILEBEAT_CLOUD_INSTRUCTIONS = {
  CONFIG: {
    OSX: {
      title: '编辑配置文件',
      textPre: 'Modify `filebeat.yml` to set the connection information for Elastic Cloud:',
      commands: ['cloud.id: "{config.cloud.id}"', 'cloud.auth: "elastic:<password>"'],
      textPost: 'Where `<password>` is the password of the `elastic` user.'
    },
    DEB: {
      title: '编辑配置文件',
      textPre: 'Modify `/etc/filebeat/filebeat.yml` to set the connection information for Elastic Cloud:',
      commands: ['cloud.id: "{config.cloud.id}"', 'cloud.auth: "elastic:<password>"'],
      textPost: 'Where `<password>` is the password of the `elastic` user.'
    },
    RPM: {
      title: '编辑配置文件',
      textPre: 'Modify `/etc/filebeat/filebeat.yml` to set the connection information for Elastic Cloud:',
      commands: ['cloud.id: "{config.cloud.id}"', 'cloud.auth: "elastic:<password>"'],
      textPost: 'Where `<password>` is the password of the `elastic` user.'
    },
    WINDOWS: {
      title: '编辑配置文件',
      textPre: 'Modify `C:\\Program Files\\Filebeat\\filebeat.yml` to set the connection information for Elastic Cloud:',
      commands: ['cloud.id: "{config.cloud.id}"', 'cloud.auth: "elastic:<password>"'],
      textPost: 'Where `<password>` is the password of the `elastic` user.'
    }
  }
};
