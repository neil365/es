"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
const FILEBEAT_ONPREM_CLOUD_INSTRUCTIONS = exports.FILEBEAT_ONPREM_CLOUD_INSTRUCTIONS = {};
