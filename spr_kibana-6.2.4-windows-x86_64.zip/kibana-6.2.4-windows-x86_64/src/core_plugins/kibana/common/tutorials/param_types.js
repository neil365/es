'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const PARAM_TYPES = exports.PARAM_TYPES = {
  NUMBER: 'number',
  STRING: 'string'
};
